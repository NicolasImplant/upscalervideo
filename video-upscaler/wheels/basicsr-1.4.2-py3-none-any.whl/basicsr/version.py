# GENERATED VERSION FILE
# TIME: Fri May  1 22:04:49 2026
__version__ = '1.4.2'
__gitsha__ = '8d56e3a'
version_info = (1, 4, 2)
